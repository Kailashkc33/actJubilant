// app/layout.tsx
import type { Metadata } from "next";
import type { Viewport } from "next";
import Image from "next/image";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

import { Atkinson_Hyperlegible } from "next/font/google";
import "./globals.css";
import AccessibilityToolbar from "../components/AccessibilityToolbar";
import MobileNav from "../components/MobileNav";

const atkinson = Atkinson_Hyperlegible({
  subsets: ["latin"],
  weight: "400",
  display: "swap",
  variable: "--font-dys",
});

export const metadata: Metadata = {
  title: "ACT Jubilant — Empowering people. Creating possibilities.",
  description:
    "Registered NDIS provider in Canberra. Personalised support, inclusive programs, and real care.",
  metadataBase: new URL("https://www.act-jubilant.org.au"),
  alternates: { canonical: "/" },
  openGraph: {
    title: "ACT Jubilant",
    description:
      "Personalised NDIS support in Canberra. Your goals, your pace — we’re here for you.",
    url: "https://www.act-jubilant.org.au",
    siteName: "ACT Jubilant",
    images: [{ url: "/images/welcome.jpg", width: 1200, height: 630 }],
    locale: "en_AU",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-AU" suppressHydrationWarning className={atkinson.variable}>
      <body>
        {/* Skip link */}
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:bg-[var(--primary-600)] focus:text-white focus:px-4 focus:py-2 focus:rounded-lg"
        >
          Skip to main content
        </a>

        <AccessibilityToolbar />

        <header role="banner" className="w-full border-b bg-[color-mix(in_oklab,var(--surface)_70%,transparent)] backdrop-blur">
          
          <div className="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
            <a href="/" className="flex items-center gap-3">
              <img
                src="/logo.png"
                alt="ACT Jubilant"
                width="300"
                height="300"
                className="rounded-xl h-12 w-auto md:h-20 md:w-20"
                style={{ maxWidth: '300px', maxHeight: '300px' }}
              />
              {/* <div aria-hidden="true" className="h-9 w-9 rounded-xl bg-[var(--primary-600)]" /> */}
              <p className="font-bold text-xl tracking-tight">
                {/* ACT <span className="text-[var(--primary-700)]">Jubilant</span> */}
              </p>
            </a>
            <nav aria-label="Main" className="hidden md:flex items-center gap-3">
              <a className="nav-link" href="/programs">Programs</a>
              <a className="nav-link" href="/reviews">Reviews</a>
              <a className="nav-link" href="/referral">Make a Referral</a>
              <a className="nav-link" href="/consultation">Book a Consultation</a>
              <a className="nav-link" href="/accessibility">Accessibility</a>
              <a className="nav-link" href="/faq">FAQ</a>
            </nav>
            <div className="md:hidden"><MobileNav /></div>
          </div>
        </header>

        <main id="main" className="mx-auto max-w-7xl px-4">
          {children}
        </main>

        <footer role="contentinfo" className="mt-16 border-t bg-[var(--surface)]">
          {/* Main footer content */}
          <div className="mx-auto max-w-7xl px-4 py-12">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              {/* Company Info */}
              <div className="lg:col-span-2">
                <div className="flex items-center gap-3 mb-4">
                  <div aria-hidden="true" className="h-10 w-10 rounded-xl bg-[var(--primary-600)]" />
                  <p className="font-bold text-xl tracking-tight">
                    ACT <span className="text-[var(--primary-700)]">Jubilant</span>
                  </p>
                </div>
                <p className="text-[var(--text-muted)] mb-4">
                  Empowering people. Creating possibilities. Registered NDIS provider 
                  offering personalised support, inclusive programs, and real care in Canberra.
                </p>
                <div className="space-y-2">
                  <p className="text-sm">
                    <strong>Phone:</strong> 
                    <a href="tel:0424488439" className="ml-1 text-[var(--primary-600)] hover:underline">
                      0424 488 439
                    </a>
                  </p>
                  <p className="text-sm">
                    <strong>Email:</strong> 
                    <a href="mailto:admin@actjubilant.com.au" className="ml-1 text-[var(--primary-600)] hover:underline">
                      admin@actjubilant.com.au
                    </a>
                  </p>
                </div>
              </div>

              {/* Quick Links */}
              <div>
                <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
                <nav aria-label="Footer navigation">
                  <ul className="space-y-2">
                    <li><a className="nav-link" href="/programs">Our Programs</a></li>
                    <li><a className="nav-link" href="/reviews">Reviews</a></li>
                    <li><a className="nav-link" href="/referral">Make a Referral</a></li>
                    <li><a className="nav-link" href="/consultation">Book Consultation</a></li>
                    <li><a className="nav-link" href="/faq">FAQ</a></li>
                  </ul>
                </nav>
              </div>

              {/* Support & Info */}
              <div>
                <h3 className="font-semibold text-lg mb-4">Support & Info</h3>
                <nav aria-label="Support navigation">
                  <ul className="space-y-2">
                    <li><a className="nav-link" href="/accessibility">Accessibility</a></li>
                    <li><a className="nav-link" href="/feedback">Feedback & Complaints</a></li>
                    <li><a className="nav-link" href="/privacy">Privacy Policy</a></li>
                    <li>
                      <a 
                        href="https://www.ndis.gov.au" 
                        className="nav-link"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        NDIS Information
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>

          {/* Acknowledgement of Country */}
          <div className="border-t bg-[color-mix(in_oklab,var(--primary-600)_5%,var(--surface))]">
            <div className="mx-auto max-w-7xl px-4 py-6">
              <p className="text-sm text-[var(--text-muted)] leading-relaxed">
                <strong>Acknowledgement of Country:</strong> We acknowledge the Ngunnawal people as the Traditional Custodians of the land on which we live and work. We pay our respects to Elders past and present, and extend that respect to all Aboriginal and Torres Strait Islander peoples.
              </p>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="border-t bg-[color-mix(in_oklab,var(--primary-600)_8%,var(--surface))]">
            <div className="mx-auto max-w-7xl px-4 py-4 flex flex-wrap items-center justify-between gap-4">
              <p className="text-sm text-[var(--text-muted)]">
                📍 Proudly supporting the Canberra community
              </p>
              <p className="text-sm text-[var(--text-muted)]">
                © 2025 ACT Jubilant. All rights reserved.
              </p>
            </div>
          </div>
        </footer>

        {/* Structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "NGO",
              name: "ACT Jubilant",
              url: "https://www.act-jubilant.org.au",
              areaServed: "Canberra, ACT",
              sameAs: [],
              serviceType: "NDIS Support Services",
            }),
          }}
        />
      </body>
    </html>
  );
}