"use server";

// Minimal validation without extra deps. Replace with zod if you prefer.
function required(v?: string) {
  return v && v.trim().length > 0 ? null : "This field is required.";
}
function isEmail(v?: string) {
  if (!v) return "This field is required.";
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  return ok ? null : "Enter a valid email.";
}
function isPhoneAU(v?: string) {
  if (!v) return "This field is required.";
  const ok = /^(\+61|0)[\d\s]{8,13}$/.test(v);
  return ok ? null : "Enter a valid phone (AU).";
}

export type ActionResult = {
  ok: boolean;
  message?: string;
  errors?: Record<string, string | null>;
};

export async function submitReferral(_: ActionResult, formData: FormData): Promise<ActionResult> {
  // Honeypot
  if (String(formData.get("website") || "").length > 0) {
    return { ok: true, message: "Thanks!" };
  }

  const data = {
    fullName: String(formData.get("fullName") || ""),
    preferredName: String(formData.get("preferredName") || ""),
    email: String(formData.get("email") || ""),
    phone: String(formData.get("phone") || ""),
    relationship: String(formData.get("relationship") || ""),
    address: String(formData.get("address") || ""),
    ndisNumber: String(formData.get("ndisNumber") || ""),
    dob: String(formData.get("dob") || ""),
    primaryLanguage: String(formData.get("primaryLanguage") || ""),
    interpreter: String(formData.get("interpreter") || "no"),
    supports: String(formData.get("supports") || ""),
    notes: String(formData.get("notes") || ""),
    consent: formData.get("consent") === "on",
  };

  const errors = {
    fullName: required(data.fullName),
    email: isEmail(data.email),
    phone: isPhoneAU(data.phone),
    relationship: required(data.relationship),
    supports: required(data.supports),
    consent: data.consent ? null : "Consent is required to proceed.",
  };

  const hasError = Object.values(errors).some(Boolean);
  if (hasError) return { ok: false, errors };

  // TODO: send to your email/CRM
  // Example (uncomment after `npm i resend` and put RESEND_API_KEY in env):
  // import { Resend } from "resend";
  // const resend = new Resend(process.env.RESEND_API_KEY!);
  // await resend.emails.send({ from:"website@act-jubilant.org.au", to:"intake@act-jubilant.org.au",
  //   subject:"New Referral - ACT Jubilant",
  //   text: JSON.stringify(data, null, 2)
  // });

  console.log("Referral submission:", data);
  return { ok: true, message: "Thanks — we’ll be in touch within 1–2 business days." };
}

export async function submitConsultation(_: ActionResult, formData: FormData): Promise<ActionResult> {
  if (String(formData.get("website") || "").length > 0) return { ok: true, message: "Thanks!" };

  const data = {
    fullName: String(formData.get("fullName") || ""),
    email: String(formData.get("email") || ""),
    phone: String(formData.get("phone") || ""),
    preferredDate: String(formData.get("preferredDate") || ""),
    preferredTime: String(formData.get("preferredTime") || ""),
    mode: String(formData.get("mode") || "phone"),
    message: String(formData.get("message") || ""),
  };

  const errors = {
    fullName: required(data.fullName),
    email: isEmail(data.email),
    phone: isPhoneAU(data.phone),
    preferredDate: required(data.preferredDate),
    preferredTime: required(data.preferredTime),
  };

  const hasError = Object.values(errors).some(Boolean);
  if (hasError) return { ok: false, errors };

  console.log("Consultation request:", data);
  return { ok: true, message: "Your consultation request is received. We’ll confirm shortly." };
}