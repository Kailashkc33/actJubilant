// app/layout.tsx
import type { Metadata } from "next";
import { Atkinson_Hyperlegible } from "next/font/google";
import "./globals.css";
import AccessibilityToolbar from "../components/AccessibilityToolbar";

const atkinson = Atkinson_Hyperlegible({
  subsets: ["latin"],
  weight: "400",
  display: "swap",
  variable: "--font-dys",
});

export const metadata: Metadata = {
  title: "ACT Jubilant — Empowering people. Creating possibilities.",
  description:
    "Registered NDIS provider in Canberra. Personalised support, inclusive programs, and real care.",
  metadataBase: new URL("https://www.act-jubilant.org.au"),
  alternates: { canonical: "/" },
  openGraph: {
    title: "ACT Jubilant",
    description:
      "Personalised NDIS support in Canberra. Your goals, your pace — we’re here for you.",
    url: "https://www.act-jubilant.org.au",
    siteName: "ACT Jubilant",
    images: [{ url: "/images/welcome.jpg", width: 1200, height: 630 }],
    locale: "en_AU",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-AU" suppressHydrationWarning className={atkinson.variable}>
      <body>
        {/* Skip link */}
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:bg-primary-600 focus:text-white focus:px-4 focus:py-2 focus:rounded-lg"
        >
          Skip to main content
        </a>

        <AccessibilityToolbar />

        <header role="banner" className="w-full border-b bg-surface/70 backdrop-blur">
          <div className="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
            <a href="/" className="flex items-center gap-3">
              <div aria-hidden="true" className="h-9 w-9 rounded-xl bg-primary-600" />
              <p className="font-bold text-xl tracking-tight">
                ACT <span className="text-primary-700">Jubilant</span>
              </p>
            </a>
            <nav aria-label="Main" className="flex items-center gap-3">
              <a className="nav-link" href="/programs">Programs</a>
              <a className="nav-link" href="/reviews">Reviews</a>
              <a className="nav-link" href="/referral">Make a Referral</a>
              <a className="nav-link" href="/consultation">Book a Consultation</a>
              <a className="nav-link" href="/accessibility">Accessibility</a>
              <a className="nav-link" href="/faq">FAQ</a>
            </nav>
          </div>
        </header>

        <main id="main" className="mx-auto max-w-7xl px-4">
          {children}
        </main>

        <footer role="contentinfo" className="mt-10 border-t bg-surface">
          <div className="mx-auto max-w-7xl px-4 py-8 flex flex-wrap items-center justify-between gap-4">
            <p>📍 Proudly supporting the Canberra community</p>
            <nav aria-label="Footer">
              <ul className="flex gap-4">
                <li><a className="nav-link" href="/privacy">Privacy</a></li>
                <li><a className="nav-link" href="/feedback">Feedback & Complaints</a></li>
                <li><a className="nav-link" href="/accessibility">Accessibility</a></li>
              </ul>
            </nav>
          </div>
        </footer>

        {/* Structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "NGO",
              name: "ACT Jubilant",
              url: "https://www.act-jubilant.org.au",
              areaServed: "Canberra, ACT",
              sameAs: [],
              serviceType: "NDIS Support Services",
            }),
          }}
        />
      </body>
    </html>
  );
}